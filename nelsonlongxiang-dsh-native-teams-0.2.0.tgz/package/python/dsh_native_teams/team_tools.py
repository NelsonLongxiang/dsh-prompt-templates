"""The team-tools extension domain: execute Python tool files for teams.

Discovers self-contained async tool functions in configured directories (one
public ``async def`` per file, filename equals the primary function name),
derives a JSON Schema from type annotations, and invokes them with a
caller-identity object the Host bridge injects. Tools return dicts and never
raise; a raised exception is converted to an ``{"error": ...}`` result here.

Method surface (namespace ``team_tools``):

- ``team_tools/list``   ``{"tool_dirs": [...]}`` → ``[{"name", "description", "parameters"}]``
- ``team_tools/invoke`` ``{"name", "args", "caller"}`` → the tool's dict result
"""

from __future__ import annotations

import asyncio
import importlib.util
import inspect
from pathlib import Path
from typing import Any, Literal, Union, get_args, get_origin, get_type_hints


def _load_module(path: Path) -> Any:
    """Import one tool file as a standalone module."""
    spec = importlib.util.spec_from_file_location(f"dsh_team_tool_{path.stem}", path)
    if spec is None or spec.loader is None:  # pragma: no cover - defensive
        raise ImportError(f"cannot load tool file: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _schema_of(annotation: Any) -> dict[str, Any]:
    """Derive one JSON Schema fragment from a Python type annotation."""
    origin = get_origin(annotation)
    if origin is Union:
        members = [arg for arg in get_args(annotation) if arg is not type(None)]
        return _schema_of(members[0]) if members else {"type": "string"}
    if origin is Literal:
        return {"type": "string", "enum": list(get_args(annotation))}
    if annotation is str:
        return {"type": "string"}
    if annotation is int:
        return {"type": "integer"}
    if annotation is float:
        return {"type": "number"}
    if annotation is bool:
        return {"type": "boolean"}
    if annotation is dict or origin is dict:
        return {"type": "object"}
    if annotation is list or origin is list:
        args = get_args(annotation)
        items = _schema_of(args[0]) if args else {}
        return {"type": "array", "items": items}
    return {"type": "string"}


def describe_function(func: Any) -> dict[str, Any]:
    """Build one tool descriptor: name, docstring description, parameter schema."""
    signature = inspect.signature(func)
    try:
        hints = get_type_hints(func)
    except Exception:  # pragma: no cover - annotations unresolvable
        hints = {}
    properties: dict[str, Any] = {}
    required: list[str] = []
    for name, parameter in signature.parameters.items():
        schema = _schema_of(hints.get(name, str))
        if parameter.default is inspect.Parameter.empty:
            required.append(name)
            properties[name] = schema
        else:
            properties[name] = {**schema, "default": parameter.default}
    return {
        "name": func.__name__,
        "description": inspect.getdoc(func) or "",
        "parameters": {
            "type": "object",
            "properties": properties,
            "required": required,
        },
    }


class TeamToolsDomain:
    """The ``team_tools`` domain: directory-scoped tool discovery and invocation."""

    def __init__(self) -> None:
        self._tools: dict[str, Any] = {}

    def _discover(self, tool_dirs: list[str]) -> None:
        self._tools = {}
        seen: set[str] = set()
        for entry in tool_dirs:
            directory = Path(entry)
            if not directory.is_dir():
                raise ValueError(f"tool directory not found: {entry}")
            for path in sorted(directory.glob("*.py")):
                if path.name.startswith("_"):
                    continue
                module = _load_module(path)
                for name, value in vars(module).items():
                    if name.startswith("_"):
                        continue
                    if inspect.iscoroutinefunction(value) and value.__module__ == module.__name__:
                        if name in seen:
                            raise ValueError(f"duplicate tool name across directories: {name}")
                        seen.add(name)
                        self._tools[name] = value

    def dispatch(self, operation: str, params: dict[str, Any]) -> Any:
        if operation == "list":
            tool_dirs = params.get("tool_dirs")
            if not isinstance(tool_dirs, list):
                raise ValueError("team_tools/list requires a tool_dirs list")
            self._discover(tool_dirs)
            return [describe_function(func) for func in self._tools.values()]
        if operation == "invoke":
            name = params.get("name")
            if not isinstance(name, str) or name not in self._tools:
                raise ValueError(f"unknown tool: {name}")
            args = params.get("args")
            if args is None:
                args = {}
            if not isinstance(args, dict):
                raise ValueError("invoke args must be an object")
            caller = params.get("caller")
            if caller is None:
                caller = {}
            if not isinstance(caller, dict):
                raise ValueError("invoke caller must be an object")
            func = self._tools[name]
            kwargs = {**args, **{k: v for k, v in caller.items() if k in inspect.signature(func).parameters}}
            try:
                return asyncio.run(func(**kwargs))
            except Exception as exc:  # tools follow the never-raise contract; a
                # raised exception is contained as an error result instead of
                # killing the serving child.
                return {"error": f"{type(exc).__name__}: {exc}"}
        raise ValueError(f"unknown method: team_tools/{operation}")
