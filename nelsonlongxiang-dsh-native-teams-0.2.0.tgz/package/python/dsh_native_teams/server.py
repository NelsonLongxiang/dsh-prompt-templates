"""Newline-delimited JSON-RPC 2.0 server over stdio.

The Host bridge (`@nelsonlongxiang/dsh-python-bridge`) spawns
``python serve.py`` and exchanges one JSON object per line: requests carry
``{"jsonrpc":"2.0","id",...,"method",...,"params":{}}`` and responses echo the
id with ``result`` or ``error``. Notifications (no ``id``) are processed
without a response.

This bundled server ships the ``team_tools`` domain (see ``team_tools.py``) so
the ``python-tools`` plugin needs no externally provided child. Methods are
``<domain>/<operation>`` (``team_tools/list``); each domain is created lazily
on its first request.
"""

from __future__ import annotations

import json
import sys
from typing import Any, BinaryIO, Callable, Optional, Protocol

from .team_tools import TeamToolsDomain


def _error(code: int, message: str, data: Any = None) -> dict[str, Any]:
    payload: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        payload["data"] = data
    return payload


class Domain(Protocol):
    """One extension domain: dispatch ``<operation>`` within its namespace."""

    def dispatch(self, operation: str, params: dict[str, Any]) -> Any: ...


def default_domains() -> dict[str, Callable[[], Domain]]:
    """The production domain table: every domain the bundled server exposes."""
    return {"team_tools": TeamToolsDomain}


class JsonRpcServer:
    """Serve every extension domain over newline-delimited JSON-RPC 2.0."""

    def __init__(self, domains: dict[str, Callable[[], Domain]]) -> None:
        self._factories = domains
        self._domains: dict[str, Domain] = {}

    def _domain(self, namespace: str) -> Domain:
        domain = self._domains.get(namespace)
        if domain is None:
            factory = self._factories.get(namespace)
            if factory is None:
                raise ValueError(f"unknown method namespace: {namespace}")
            domain = factory()
            self._domains[namespace] = domain
        return domain

    def handle(self, request: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Handle one parsed request; ``None`` for notifications."""
        method = request.get("method")
        params = request.get("params") or {}
        request_id = request.get("id")
        try:
            result = self._dispatch(method, params)
        except ValueError as exc:
            return self._response(request_id, error=_error(-32000, str(exc)))
        except Exception as exc:  # noqa: BLE001 -- reported to the peer, never raised
            return self._response(
                request_id, error=_error(-32603, f"internal error: {exc}")
            )
        if request_id is None:
            return None
        return self._response(request_id, result=result)

    def _dispatch(self, method: Optional[str], params: dict[str, Any]) -> Any:
        if not isinstance(method, str) or "/" not in method:
            raise ValueError(f"unknown method: {method}")
        namespace, _, operation = method.partition("/")
        return self._domain(namespace).dispatch(operation, params)

    def _response(
        self,
        request_id: Any,
        result: Any = None,
        error: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
        if error is not None:
            payload["error"] = error
        else:
            payload["result"] = result
        return payload

    def serve(
        self,
        stdin: BinaryIO = sys.stdin.buffer,
        stdout: BinaryIO = sys.stdout.buffer,
    ) -> None:
        """Read requests line by line until EOF, writing one response per request."""
        for raw in stdin:
            line = raw.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError as exc:
                response = self._response(
                    None, error=_error(-32700, f"parse error: {exc}")
                )
                stdout.write(json.dumps(response).encode("utf-8") + b"\n")
                stdout.flush()
                continue
            response = self.handle(request)
            if response is not None:
                stdout.write(json.dumps(response).encode("utf-8") + b"\n")
                stdout.flush()
