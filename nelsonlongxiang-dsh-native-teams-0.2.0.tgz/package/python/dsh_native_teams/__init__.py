"""Bundled Python backend for dsh-native-teams.

Ships the JSON-RPC ``team_tools`` domain so the ``python-tools`` plugin can
point at this package's own ``serve.py`` instead of an externally provided
child.
"""
