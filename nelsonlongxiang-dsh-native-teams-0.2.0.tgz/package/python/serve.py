#!/usr/bin/env python3
"""Entry point for the bundled team-tools JSON-RPC server.

The ``python-tools`` plugin's default command resolves here
(``python <package>/python/serve.py``). Reads newline-delimited JSON-RPC
requests from stdin and writes responses to stdout.
"""

import sys
from pathlib import Path

# Running as a script puts this directory on sys.path; keep the package
# importable even when launched through a wrapper that only knows the file.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from dsh_native_teams.server import serve

if __name__ == "__main__":
    serve()
