/**
 * Team-directory provider: parses one team directory at load and registers
 * the declaration on `ctx.teams`. Mount one instance per team; the directory
 * basename is the team name and the directory is the single authority.
 *
 * With watching on (default), declaration edits re-parse and re-register the
 * team in place — the dev role edits its own declaration files and the next
 * routed round already sees the new members and persona inputs. A re-parse
 * failure (an editor's intermediate state) is logged and skipped; the last
 * good registration stays live until a parseable state returns.
 *
 * @module @nelsonlongxiang/dsh-native-teams/filesystem
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type TeamsRegistry from './index.ts';
import type { SkillRegistry } from '@deepseek-ai/dsh-skill';
export { parseTeamDirectory, parseTeamSkills, renderActionDoc } from './parse.ts';
export declare const name = "teams-filesystem";
export declare const inject: string[];
/** Default quiet period before a declaration change counts as settled. */
export declare const DEFAULT_WATCH_STABILITY_THRESHOLD_MS = 200;
/** Config: which team directory this instance parses and registers. */
export interface Config {
    /** Team directory, resolved against the process working directory. */
    readonly dir: string;
    /**
     * Re-parse and re-register on declaration changes (default true). Turn off
     * for compositions that reload the whole fiber instead.
     */
    readonly watch?: boolean;
    /** Milliseconds of quiet before a change counts as settled (default 200). */
    readonly watchStabilityThresholdMs?: number;
}
export declare const Config: z<Config>;
/** Registrations a team mount owns: the team row plus its projected skills. */
export interface TeamRegistrations {
    /** Disposer of the `ctx.teams` registration. */
    readonly team: () => void;
    /** Disposers of the projected `ctx.skills` registrations. */
    readonly skills: readonly (() => void)[];
    /** Dispose every registration this bundle owns. */
    dispose(): void;
}
/**
 * Re-parse a team directory and swap its registry registrations in place.
 * @param dir - the team directory to re-parse.
 * @param registry - the teams registry holding the current registration.
 * @param skills - the skill registry receiving the projected `skills/` tree.
 * @param current - the registration bundle being replaced.
 * @returns the new registration bundle.
 * @throws when the directory no longer parses (the caller keeps `current`).
 */
export declare function reloadTeamRegistration(dir: string, registry: Pick<TeamsRegistry, 'registerTeam'>, skills: Pick<SkillRegistry, 'register'>, current: TeamRegistrations): TeamRegistrations;
/** Register a team directory's declaration and projected skills. */
export declare function registerTeamDirectory(dir: string, registry: Pick<TeamsRegistry, 'registerTeam'>, skills: Pick<SkillRegistry, 'register'>): TeamRegistrations;
/**
 * Converge one watched team directory's registration to its on-disk state.
 * @param dir - the team directory.
 * @param registry - the teams registry.
 * @param skills - the skill registry receiving the projected `skills/` tree.
 * @param current - the bundle the watcher currently holds, if any.
 * @returns the next bundle, or `undefined` when the directory is unmarked or
 *   disabled (the current bundle is disposed).
 * @throws when a marked directory fails to parse (the caller keeps `current`).
 */
export declare function syncTeamRegistration(dir: string, registry: Pick<TeamsRegistry, 'registerTeam'>, skills: Pick<SkillRegistry, 'register'>, current: TeamRegistrations | undefined): TeamRegistrations | undefined;
export declare function apply(ctx: Context, config: Config): void;
