/**
 * Main-chat mount: the main team's dispatcher becomes the top-level
 * conversation persona. The team itself is NOT parsed or registered here —
 * the composition's team provider owns that (mount the filesystem provider
 * for the same directory; it registers the team and projects `skills/`). A
 * duplicate registration is exactly the boot failure this split avoids.
 * What this Consumer owns is the persona: the registered team's dispatcher
 * four-layer prompt renders as a system-prompt section directly after the
 * deployment persona — the main conversation's directory-authored face.
 * The section text resolves the team at each assembly (scope-aware), so the
 * consumer's loader entry carries no boot-order dependency on the provider's
 * entry: registration state across plugins is not self-contained at load,
 * and the first assembly is the earliest resolvable point to fail loud.
 *
 * @module @nelsonlongxiang/dsh-native-teams/main-chat
 */
import type { Context } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
export declare const name = "teams-main-chat";
export declare const inject: string[];
/** Config: which registered team supplies the main conversation. */
export interface Config {
    /** Registered team name (the directory basename its provider mounted). */
    readonly team: string;
}
export declare const Config: s<Config>;
/** The main-chat persona section's prompt order: directly after the persona. */
export declare const MAIN_CHAT_SECTION_ORDER = 1;
/**
 * Mount the main conversation's persona from a registered team.
 * @param ctx - Cordis context carrying the teams and system-prompt services.
 * @param config - the registered main team's name.
 */
export declare function apply(ctx: Context, config: Config): void;
