/**
 * Model-facing team routing: the Consumer of the teams seam. One instance
 * registers `route_to_team` (address a team dispatcher); a second instance
 * registers `route_to_agent` (address a member agent, by bare name inside the
 * caller's team or qualified `team/agent`). Both tools run one blocking round
 * of a durable continuable child per addressed role and return its final
 * assistant text; repeat routes reuse the child's conversation.
 *
 * @module @nelsonlongxiang/dsh-native-teams/tool-route
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { TeamDeclaration, TeamSummary } from './index.ts';
export declare const name = "tool-route";
export declare const inject: string[];
/** Config: which routing role this instance serves. */
export interface Config {
    /** Routing role: address a team dispatcher or a member agent. */
    readonly target: 'team' | 'agent' | 'dev';
    /** The `ctx.subagents` continuable provider runs children (e.g. `spawn`). */
    readonly provider: string;
    /**
     * Model-facing tool name. Defaults to `route_to_team` or `route_to_agent`
     * by target; each loaded instance must use a distinct name.
     */
    readonly toolName?: string;
    /**
     * Absolute delegation-depth cap for routed children (default `2`: a
     * dispatcher at depth 1 whose member agents are leaves).
     */
    readonly maxDepth?: number;
    /**
     * Tools removed from member-agent children so leaves cannot route. Defaults
     * to this instance's own tool name; list the team-routing instance's tool
     * name here too when both instances are mounted.
     */
    readonly agentDenyTools?: string[];
    /**
     * The dev role's whole tool surface (an allow list: the dev child sees these
     * tools and nothing else). Defaults to the filesystem editing tools
     * `read`, `write`, `edit`.
     */
    readonly devAllowTools?: string[];
}
export declare const Config: z<Config>;
/**
 * Render the member-agent catalog appended to a dispatcher persona so the
 * dispatcher can address its team without another lookup surface.
 * @param team - the team whose members are listed.
 * @returns the catalog section text.
 */
export declare function renderAgentCatalog(team: TeamDeclaration): string;
/**
 * Render the team-routing prompt section from the viewing scope's catalog.
 * @param teams - winning catalog summaries for the viewing scope.
 * @returns the section text.
 */
export declare function renderTeamCatalogSection(teams: readonly TeamSummary[]): string;
/**
 * Render the agent-routing guidance section for member dispatchers.
 * @param toolName - the configured agent-routing tool name.
 * @returns the section text.
 */
export declare function renderAgentRoutingSection(toolName: string): string;
/**
 * Render the dev-routing guidance section.
 * @param toolName - the configured dev-routing tool name.
 * @returns the section text.
 */
export declare function renderDevRoutingSection(toolName: string): string;
/**
 * The default dev-role persona for teams that declare no `agents/dev-agent/`.
 * @param team - the team the developer maintains.
 * @returns the persona layers.
 */
export declare function defaultDevPrompt(team: string): {
    readonly soul: string;
};
export declare function apply(ctx: Context, config: Config): void;
