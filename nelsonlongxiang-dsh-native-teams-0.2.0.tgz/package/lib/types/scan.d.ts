/**
 * Team-root scanner: registers every marked team directory under the
 * configured roots. A subdirectory declares a team by carrying
 * `team_chat/SOUL.md`; anything else under a root (shared resources, notes,
 * data directories) is not a team and is skipped without error. A `.disabled`
 * marker file holds a marked team out of rotation without deleting it, and a
 * disabled team is never parsed — a half-written draft does not block boot.
 * One marked team that fails to parse rejects the whole scan, and so does a
 * scan that finds no marked team at all: a half-loaded or empty roster is a
 * misconfigured deployment, not a degraded one.
 *
 * With watching on (default), settled declaration edits converge each watched
 * directory's registration to its on-disk state: an edit re-registers the
 * team in place, a newly marked directory registers, and a `.disabled`
 * marker or a removed marker unregisters. A re-parse failure (an editor's
 * intermediate state) is logged and skipped; the last good registration stays
 * live until a parseable state returns.
 *
 * @module @nelsonlongxiang/dsh-native-teams/scan
 */
import type { Context } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
export declare const name = "teams-filesystem-scan";
export declare const inject: string[];
/** The conventional deployment root: drop a marked directory there and it is a team. */
export declare const DEFAULT_TEAMS_ROOT = ".agents/teams";
/** Config: the roots whose subdirectories declare teams. */
export interface Config {
    /** Team roots, each resolved against the process working directory; defaults to the conventional root. */
    readonly roots?: string[];
    /**
     * Converge registrations to on-disk state on settled declaration changes
     * (default true). Turn off for compositions that reload the whole fiber
     * instead.
     */
    readonly watch?: boolean;
    /** Milliseconds of quiet before a change counts as settled (default 200). */
    readonly watchStabilityThresholdMs?: number;
}
export declare const Config: s<Config>;
/**
 * Scan the configured roots and register every marked team; with watching on,
 * converge each watched team's registration to its on-disk state on settled
 * edits.
 * @param ctx - Cordis context carrying the teams and skills services.
 * @param config - the team roots and watcher settings.
 */
export declare function apply(ctx: Context, config: Config): void;
