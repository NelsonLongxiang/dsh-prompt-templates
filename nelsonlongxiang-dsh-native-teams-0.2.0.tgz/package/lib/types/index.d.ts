/**
 * Teams registry: the Service Definition role of the declarative team seam.
 *
 * Provider plugins (such as `@nelsonlongxiang/dsh-native-teams/filesystem`) parse one
 * team's directory declarations and register the result here. This service
 * only merges layered registrations, resolves fail-closed membership lookups,
 * and exposes the catalog summaries routing consumers show to models.
 *
 * @module @nelsonlongxiang/dsh-native-teams
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import type { TeamAgentDeclaration, TeamDeclaration, TeamSummary, TeamViewOptions } from './types.ts';
export * from './types.ts';
/**
 * Return whether a string is a valid team or member-agent name.
 * @param name - candidate name to validate.
 * @returns whether the name matches the shared name grammar.
 */
export declare function isTeamName(name: string): boolean;
/**
 * Render one role's four-layer prompt into the persona text handed to a child
 * agent. Layers render in a fixed order with headers; absent layers vanish.
 * @param prompt - the role's parsed prompt layers.
 * @returns the complete persona text.
 */
export declare function renderTeamPrompt(prompt: TeamDeclaration['dispatcher']): string;
/**
 * The durable continuable-child label addressing one team's dispatcher.
 * @param team - the team name.
 * @returns the dispatcher label (the team name itself).
 */
export declare function teamLabel(team: string): string;
/**
 * The durable continuable-child label addressing one team's member agent.
 * @param team - the owning team name.
 * @param agent - the member agent name.
 * @returns the `team/agent` label.
 */
export declare function teamAgentLabel(team: string, agent: string): string;
/** One parsed durable child label. `agent` is absent for dispatcher labels. */
export interface ParsedTeamRoleLabel {
    readonly team: string;
    readonly agent?: string;
}
/**
 * Parse a durable child label back into its team and optional agent.
 * @param label - the label to parse.
 * @returns the addressed team and agent, or `undefined` when the label is not
 *   a well-formed team or team/agent pair.
 */
export declare function parseTeamRoleLabel(label: string): ParsedTeamRoleLabel | undefined;
/** Registry configuration; no settings are supported. */
export type TeamsConfig = Record<string, never>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        teams: TeamsRegistry;
    }
    interface Events {
        /**
         * A registered team declaration may have been added, replaced, or removed.
         * This is an unfiltered invalidation notification; consumers refetch the
         * catalog for their own view options. Listener failures are contained and
         * cannot veto the registry mutation.
         * @mode emit
         */
        'teams/change'(): void;
    }
}
/**
 * Layered registry of team declarations, the host+per-scope shape the tools
 * and skills registries established. A registration files into the layer of
 * its calling context's scope: host rows land in the global layer, while a
 * team plugin mounted by an agent preset's standing composition lands in that
 * preset's layer. A read merges the global layer with the viewing scope's
 * chain; the nearest layer's entry wins a duplicate team name outright.
 */
export declare class TeamsRegistry extends Service {
    static Config: Schema<TeamsConfig>;
    private readonly layers;
    constructor(ctx: Context);
    /**
     * Register one parsed team declaration into the calling context's layer: a
     * scoped context registers for that scope alone, an unscoped context
     * registers globally. Invalid declarations and duplicate names within one
     * layer throw; fiber disposal unregisters the team and notifies consumers.
     * @param team - the parsed declaration; ownership stays with the caller.
     * @returns the exact Cordis effect disposer that unregisters this team.
     */
    registerTeam(team: TeamDeclaration): () => void;
    /**
     * List catalog summaries for the viewing scope.
     * @param options - view options; `scope` selects the viewing agent's layers.
     * @returns all sorted winning summaries.
     */
    listTeams(options?: TeamViewOptions): TeamSummary[];
    /**
     * Resolve one team declaration.
     * @param name - team name.
     * @param options - view options; `scope` selects the viewing agent's layers.
     * @returns the winning declaration, or `undefined` when no registered team
     *   carries that name.
     */
    getTeam(name: string, options?: TeamViewOptions): TeamDeclaration | undefined;
    /**
     * Resolve one member agent with fail-closed membership: the agent must
     * belong to the named registered team.
     * @param team - owning team name.
     * @param agent - member agent name.
     * @param options - view options; `scope` selects the viewing agent's layers.
     * @returns the member declaration, or `undefined` when either the team or
     *   the membership is unknown.
     */
    getAgent(team: string, agent: string, options?: TeamViewOptions): TeamAgentDeclaration | undefined;
    /** Merge the global layer with the viewing scope's chain; nearest layer wins. */
    private collect;
    /** Notify catalog observers without making their refresh work load-bearing. */
    private notifyChange;
}
export default TeamsRegistry;
