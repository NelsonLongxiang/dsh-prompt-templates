/**
 * Declaration contracts for the teams capability seam.
 *
 * @module @nelsonlongxiang/dsh-native-teams
 */
import type { ScopeKey } from '@deepseek-ai/dsh-scope';
/** Shared name grammar for teams and their member agents: `^[a-z0-9][a-z0-9-]{1,30}$`. */
export declare const TEAM_NAME_PATTERN: RegExp;
/** One role's four prompt layers parsed from a team directory. */
export interface TeamPrompt {
    /** Identity layer (`SOUL.md` body); always non-empty. */
    readonly soul: string;
    /** User-model layer (`memories/USER.md`). */
    readonly user?: string;
    /** Action-rules layer (`ACTION.md`, frontmatter rendered into text). */
    readonly action?: string;
    /** Resident-memory layer (`memories/MEMORY.md` and siblings). */
    readonly memories?: string;
}
/** One role's declared LLM route: the model a dispatched child runs, with an optional provider. */
export interface TeamRoleRoute {
    /** Model id interpreted by the selected provider adapter. */
    readonly model: string;
    /** Provider route; must have a registered adapter at child-creation time. */
    readonly provider?: string;
}
/** One atomic agent declared under a team. Leaf of the delegation tree: it never routes. */
export interface TeamAgentDeclaration {
    /** Member name, unique within its team and matching the shared name grammar. */
    readonly name: string;
    /** The agent's four-layer prompt. */
    readonly prompt: TeamPrompt;
    /** Marks a read-only observer kept outside dispatch rotation. */
    readonly readOnly: boolean;
    /**
     * The agent's declared tool face: global tool names a dispatched member sees
     * (an allow list — every other tool is hidden and refuses to execute).
     * Absent means the team's unrestricted child face.
     */
    readonly tools?: readonly string[];
    /**
     * The agent's declared skill face: skill names a dispatched member sees
     * (an allow list — every other skill leaves the catalog and refuses to
     * load). Absent means the team's unrestricted child skill face.
     */
    readonly skills?: readonly string[];
    /**
     * The agent's declared LLM route. Applies when the routing consumer first
     * creates the role's continuable child; repeat routes keep the durable
     * child's recorded route. Absent inherits the routing parent's route.
     */
    readonly route?: TeamRoleRoute;
}
/** One team declaration registered by a team provider plugin. */
export interface TeamDeclaration {
    /** Team name matching the shared name grammar. */
    readonly name: string;
    /** Routing keywords for catalog consumers. */
    readonly keywords: readonly string[];
    /** One-paragraph capability description shown to routing models. */
    readonly description: string;
    /** The team dispatcher's prompt; the dispatcher assigns work and executes no business tools. */
    readonly dispatcher: TeamPrompt;
    /**
     * The dispatcher's declared LLM route: applied when the routing consumer
     * first creates the dispatcher child; repeat routes keep the durable
     * child's recorded route. Absent inherits the routing parent's route.
     */
    readonly dispatcherRoute?: TeamRoleRoute;
    /**
     * The team's default tool face: global tool names every dispatched member
     * sees unless the member declares its own list (the member's declaration
     * replaces, not widens, the team baseline). Absent means members inherit
     * the unrestricted child face unless they declare otherwise.
     */
    readonly tools?: readonly string[];
    /**
     * The team's default skill face: names every dispatched member sees unless
     * the member declares its own list (the member's declaration replaces, not
     * widens, the team baseline).
     */
    readonly skills?: readonly string[];
    /** Member agents; at least one is required. */
    readonly agents: readonly TeamAgentDeclaration[];
    /**
     * The team's reserved developer role, declared under `agents/dev-agent/`.
     * Outside dispatch rotation (absent from the member catalog and
     * `getAgent`); addressed by the dev-routing tool. It maintains the team's
     * own declaration files.
     */
    readonly devAgent?: TeamAgentDeclaration;
}
/** Invocation-neutral catalog entry describing one registered team. */
export interface TeamSummary {
    readonly name: string;
    readonly description: string;
    readonly keywords: readonly string[];
}
/** Registry read options: the viewing scope whose layer chain participates in the merge. */
export interface TeamViewOptions {
    /** Viewing scope (the calling agent); omitted reads the global layer alone. */
    readonly scope?: ScopeKey | undefined;
}
