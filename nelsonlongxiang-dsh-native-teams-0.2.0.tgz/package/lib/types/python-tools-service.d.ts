/**
 * Python team-tools registry service: a shared Python bridge and tool surface
 * that other plugins can register into.
 *
 * The service owns one `pythonBridge` child and keeps the merged set of
 * `toolDirs` from every registration. Registrations come and go as team
 * plugins mount and unmount; the service refreshes the exposed tool surface
 * lazily and reuses the same bridge for all callers.
 *
 * @module @nelsonlongxiang/dsh-native-teams/python-tools-service
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ParameterSchemaSpec } from '@deepseek-ai/dsh-tools';
import { PythonBridgeError } from '@nelsonlongxiang/dsh-python-bridge';
import type { PythonBridge } from '@nelsonlongxiang/dsh-python-bridge';
export { PythonBridgeError };
export type { PythonBridge };
/** Default per-call timeout (a team tool is a bounded business operation). */
export declare const DEFAULT_TOOL_CALL_TIMEOUT_MS = 30000;
/** Default grace for the child's EOF-driven quiesce (PythonBridge contract). */
export declare const DEFAULT_EOF_GRACE_MS = 6000;
/**
 * The default bridge command: run this package's bundled `python/serve.py`
 * with the platform's Python executable. The server ships the `team_tools`
 * domain, so `./python-tools` needs no externally provided child.
 * @returns the argv for the bundled server.
 */
export declare function defaultCommand(): string[];
/** Service config: the bridge command and defaults for every registration. */
export interface Config {
    /**
     * Complete argv; `argv[0]` is the executable. Defaults to the bundled
     * `python/serve.py` server.
     */
    readonly command?: string[];
    /** Tool directories scanned by the Python side; ownership follows config. */
    readonly toolDirs: string[];
    /** Absolute working directory for the child; defaults to the process cwd. */
    readonly cwd?: string;
    /** Per-tool-call timeout in ms (default 30000). */
    readonly toolCallTimeoutMs?: number;
    /** Grace (ms) for the child's stdin-EOF quiesce (default 6000). */
    readonly eofGraceMs?: number;
    /**
     * Registered tool-name prefix; the public name is `<prefix>__<name>`
     * (default `py`). An empty string registers bare names.
     */
    readonly namePrefix?: string;
}
export declare const Config: z<Config>;
/** One tool registration from a consumer plugin. */
export interface PythonToolRegistration {
    /** Tool directories scanned by the Python side for this registration. */
    readonly toolDirs: readonly string[];
    /** Per-tool-call timeout override; defaults to the service config. */
    readonly toolCallTimeoutMs?: number;
}
/** The caller identity injected into every invoke (wire boundary shape). */
interface ToolCaller {
    readonly layer: string;
    readonly team?: string;
    readonly agent?: string;
}
/**
 * Derive the caller identity from the calling agent's durable session state.
 * Depth 0 is the top-level router; a continuable child's descriptor label
 * carries its team and member name.
 * @param agent - the agent whose tool call runs, when one exists.
 * @returns the identity injected into the Python side.
 */
export declare function callerIdentityOf(agent: Agent | undefined): ToolCaller;
/**
 * The registered public name for one Python tool.
 * @param prefix - configured namespace prefix (may be empty).
 * @param toolName - the Python function name.
 * @returns the ToolRuntime-visible name.
 */
export declare function publicName(prefix: string, toolName: string): string;
/**
 * Convert the Python side's object-rooted JSON Schema into the author
 * property map `defineTool.parameters` expects. This is a wire-boundary
 * conversion: only the fields the author schema supports survive (`type`,
 * `description`, `enum`, `items` for arrays); requiredness moves onto each
 * property. An unusable descriptor throws so a bad tool list fails the fiber
 * at load.
 * @param schema - the `team_tools/list` parameters descriptor.
 * @param toolName - the owning tool, for diagnostics.
 * @returns the property map for `defineTool`.
 */
export declare function propertyMapOf(schema: Record<string, unknown>, toolName: string): ParameterSchemaSpec;
/**
 * Shared Python tool registry service. One instance is provided by the
 * `python-tools` plugin; other plugins inject `ctx.pythonTools` to register
 * their own tool directories without spawning a private bridge.
 */
export declare class PythonTools {
    private readonly ctx;
    private readonly config;
    private nextId;
    private readonly registrations;
    private readonly toolDisposers;
    private bridge;
    private currentToolDirs;
    private refreshPromise;
    private pendingRefresh;
    private disposed;
    private readonly command;
    constructor(ctx: Context, config: Config);
    /**
     * Register a set of tool directories. The returned promise settles once the
     * tool surface has been refreshed to include this registration, so a caller
     * can await failure at load time.
     * @param input - directories and optional per-registration timeout.
     * @returns a disposer that removes the registration and refreshes the tool
     *   surface; the returned function is synchronous and safe to call from a
     *   plugin teardown.
     */
    register(input: PythonToolRegistration): Promise<() => void>;
    /**
     * Dispose the whole service: unregister every tool and close the bridge.
     */
    dispose(): Promise<void>;
    private refreshUntilSettled;
    private refresh;
    private doRefresh;
    private reconcileTools;
    /**
     * Invoke one tool, replaying discovery once when the serving child restarted
     * without a `team_tools/list` pass: a respawned child answers every invoke
     * with `unknown tool:` until discovery is replayed. The rejection proves
     * the tool did not run, so the retry cannot execute it twice; registered
     * tools are `isConcurrencySafe: false`, so the replay and retry serialize
     * with other invokes.
     */
    private invokeDiscovered;
    private ensureBridge;
    private disposeBridge;
    private disposeAllTools;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Shared Python tool registry service. */
        pythonTools: PythonTools;
    }
}
