/**
 * Python team-tools bridge plugin: provides the `ctx.pythonTools` service
 * and, when configured with `toolDirs`, registers those directories through
 * the service.
 *
 * Other plugins that need Python tools should inject `pythonTools` and call
 * `ctx.pythonTools.register({ toolDirs: [...] })` instead of mounting a
 * private bridge.
 *
 * @module @nelsonlongxiang/dsh-native-teams/python-tools
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config as PythonToolsConfig, type Config as PythonToolsServiceConfig } from './python-tools-service.ts';
export * from './python-tools-service.ts';
export declare const name = "python-tools-bridge";
export declare const inject: string[];
/** Plugin config: bridge command plus optional directories to load at mount. */
export type Config = PythonToolsServiceConfig;
export declare const Config: import("@deepseek-ai/schemastery").default<PythonToolsConfig>;
export declare function apply(ctx: Context, config: Config): Promise<() => void>;
