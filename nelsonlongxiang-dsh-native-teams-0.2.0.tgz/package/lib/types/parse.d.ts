/**
 * Team-directory parsing: the Markdown declaration format behind
 * `@nelsonlongxiang/dsh-native-teams/filesystem`.
 *
 * A team directory is the authority for one team declaration:
 *
 * ```
 * <dir>/team_chat/SOUL.md        frontmatter: keywords, description; body: dispatcher soul
 * <dir>/team_chat/ACTION.md      optional action rules (four-piece frontmatter + body)
 * <dir>/team_chat/memories/      optional USER.md, MEMORY.md, *-memory.md
 * <dir>/agents/<name>/           one member agent per directory (same role files)
 * ```
 *
 * @module @nelsonlongxiang/dsh-native-teams/filesystem/parse
 */
import type { TeamDeclaration } from './index.ts';
/**
 * Render one ACTION.md file into the action prompt layer. Frontmatter is
 * optional; when present, `whenToUse` and `dontDo` are required and render as
 * titled sections before the body.
 * @param raw - complete ACTION.md content.
 * @param path - file path for error messages.
 * @returns the rendered action layer text.
 */
export declare function renderActionDoc(raw: string, path: string): string;
/**
 * Parse one team directory into a complete declaration.
 * @param dir - team directory whose basename is the team name.
 * @returns the declaration ready for `ctx.teams.registerTeam`.
 * @throws when a required file is missing or any declaration is malformed;
 *   every error names the offending path.
 */
export declare function parseTeamDirectory(dir: string): TeamDeclaration;
/** One projected team skill: a `skills/<name>/SKILL.md` directory parsed for runtime registration. */
export interface ParsedTeamSkill {
    /** Kebab-case skill name from frontmatter. */
    readonly name: string;
    /** One-line description from frontmatter. */
    readonly description: string;
    /** Markdown instruction body. */
    readonly content: string;
    /** Absolute SKILL.md path. */
    readonly path: string;
}
/**
 * Parse a team directory's `skills/` tree: one skill per subdirectory carrying
 * a `SKILL.md` whose frontmatter must name and describe it. A missing or empty
 * `skills/` directory projects nothing.
 * @param teamDir - the team directory whose `skills/` subtree to parse.
 * @returns the projected skills in directory order.
 */
export declare function parseTeamSkills(teamDir: string): ParsedTeamSkill[];
