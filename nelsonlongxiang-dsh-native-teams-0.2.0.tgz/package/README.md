# @nelsonlongxiang/dsh-native-teams

Expert Teams for [DeepSeek Harness](https://gitee.com/NelsonLongXiang/deepseek-harness):
agents organized as declared team directories. A routing model picks a team,
the team dispatcher picks a member agent, and the member executes with a
persona and tool scope derived from its declaration — directories are the
authority, never hand-registered identity. Ported from the Expert Teams
blueprint and maintained here as an independent plugin per the
independent-repo plugin policy.

Host-only plugin (no client face). One package, six entry points:

| Entry | Role |
|---|---|
| `.` | Teams registry (`ctx.teams`): layered declaration registration and fail-closed membership lookup |
| `./filesystem` | One-directory provider: parses one team directory and registers it (plus register/reload/sync helpers) |
| `./scan` | Root scanner: registers every marked team directory under the configured roots, converges on edits |
| `./main-chat` | The `main` team's dispatcher becomes the top-level conversation persona |
| `./tool-route` | Model-facing `route_to_team` / `route_to_agent` / `route_to_dev` delegation tools (one instance per target) |
| `./python-tools` | Provides the `ctx.pythonTools` service plus a bundled Python `team_tools` JSON-RPC server; Python team-tool files register into `ctx.tools` over stdio |

`cordis.patch.yml` (the `dsh.bundle` layer) mounts the whole team plane as
one install.

## Team directories

A team is a directory carrying `team_chat/SOUL.md` — that marker alone makes
it a team. A `.disabled` marker file holds a marked team out of rotation
without deleting it, and a disabled team is never parsed. Anything else under
a root (shared resources, notes, data) is skipped silently.

```
<dir>/team_chat/SOUL.md        frontmatter: keywords, description, tools, skills, provider, model; body: dispatcher soul
<dir>/team_chat/ACTION.md      optional action rules (whenToUse/preconditions/sideEffects/dontDo + body)
<dir>/team_chat/memories/      optional USER.md, MEMORY.md, *-memory.md (resident memories)
<dir>/agents/<name>/           one member agent per directory (same role files)
<dir>/agents/dev-agent/        optional reserved developer role (maintains the declarations)
<dir>/skills/<name>/SKILL.md   optional skills projected onto the host skill registry
```

Names match `^[a-z0-9][a-z0-9-]{1,30}$`. Each role's prompt renders four
layers in a fixed order — Soul, User, Actions, Memories — with absent layers
omitted. A member's `tools:`/`skills:` frontmatter is an allow list replacing
the team baseline; `provider`/`model` route the role's children to a specific
LLM (applied when the child is first created; durable children keep their
recorded route).

## Install

```sh
npx -p @deepseek-ai/dsh dsh plugin --profile <name> add @nelsonlongxiang/dsh-native-teams
```

The package resolves from the team Gitea npm registry (endpoint
`http://192.168.3.88:3000/api/packages/jf-tech/npm/`): the user-level
`.npmrc` carries the `@nelsonlongxiang` scope route and the registry token —
this repository's committed `.npmrc` carries the route alone. A local path
install also works (run `pnpm build` first so `lib/` is current). Restart the
profile after installing.

Requirements on the host composition:

- The profile must mount the system-prompt and tools services (every dsh
  profile does).
- If the composition's agent spine bundles its own skill registry
  (agent-spine-demo does), disable it (`skills: { enabled: false }` on the
  spine row): the patch's `skills` row is the registry the team plane
  projects onto, and a second registry service fails loud at boot.
- The scan roots default to `.agents/teams` relative to the process working
  directory — run `dsh` from your workspace root, or override the
  `teams-scan` row's `roots` from your own `cordis.patch.yml` (restate the
  whole config).

This repository dogfoods itself: `.agents/teams/` at the root carries the
`main` and `god-system` demo teams.

### Optional: Python team tools

`./python-tools` is not in the default patch (it spawns a Python child).
Mount it as your own row when a team's Python tool files should become
native tools. The package bundles the `team_tools`-serving Python server, so
`command` defaults to running `python/serve.py` from this package:

```yaml
- insert:
    - id: teams-python-tools
      name: '@nelsonlongxiang/dsh-native-teams/python-tools'
      config:
        toolDirs: ['<workspace>/tools']   # command defaults to the bundled server
```

To use an external `team_tools`-serving child instead, pass `command`
explicitly (e.g. `command: ['dsh-ext', 'serve']`). The child must speak the
`team_tools/list` + `team_tools/invoke` JSON-RPC methods. Caller identity is
derived from the calling agent's durable session state, never from model
arguments.

Other plugins (including future team plugins) can share the same Python
child through the service:

```ts
return {
  inject: ['pythonTools'],
  apply(ctx) {
    return ctx.pythonTools.register({ toolDirs: ['.agents/teams/ops/tools'] })
  },
}
```

## Model experience

### Routing tools

What the model sees, after the plane mounts:

- `route_to_team(team, message)` — routes a whole task to one declared team;
  the dispatcher assigns it to a member and the call returns the team
  conversation's final answer for the round. Repeat routes continue that
  conversation.
- `route_to_agent(agent, message)` — routes executable work to one member
  (bare name inside the caller's team, `"team/agent"` from the top level).
  Repeat routes continue that agent's conversation.
- `route_to_dev(team, message)` — routes declaration maintenance to a team's
  developer, whose tool face defaults to `read`/`write`/`edit`.

Token effect: three fixed tool schemas plus the routing prompt sections (the
team catalog for `route_to_team`, routing guidance for the others, the
member catalog appended to each dispatcher persona). KV-cache effect: the
schemas and static sections are stable per composition; the team catalog
section re-renders when registrations change, invalidating the request suffix
from that section on.

Routed rounds are serialized per addressed role (one round per role at a
time, queued in call order); parallel routes to different roles commute.

### Main-chat persona

With the default `teams-main-chat` row, every model request in the main
conversation carries the `main` team's dispatcher four-layer prompt directly
after the deployment persona. Disable the row (`disabled: true`) for headless
profiles, or point `team` at another registered team.

## Known limitations and deferred work

- **Pinned against dsh 0.1.0-rc.6 peers** — `watchProviderTool` is vendored
  locally in `./tool-route` and two schema-value narrows exist because the
  published rc.6 peer types predate them; replace with the upstream surfaces
  once a published range carries them.
- **No real-API routing round coverage in this repository** — the suite is
  keyless (unit + real-Loader composition boot); a keyed e2e lane exercising
  a full routed round is deferred to the host repo's example coverage.
- **Git installs need a build strategy** — registry installs are the
  distribution path; a Git clone install has no `prepare` and no committed
  `lib/` (deferred until a real Git consumer appears).

## Development

```sh
pnpm install
pnpm typecheck   # tsc --noEmit
pnpm build       # tsc emit to lib/ + lib/types/
pnpm test        # build + vitest (unit specs + real dsh-app-boot boot) + Python pytest
```

The composition test boots `tests/fixtures/composition/cordis.yml` through
the same loader path a deployment takes and asserts the scanned roster, all
three route tools, and the mounted persona. The Python tests run the bundled
`team_tools` domain against committed fixture tool directories
(`python/tests/fixtures/`).

## License

MIT
